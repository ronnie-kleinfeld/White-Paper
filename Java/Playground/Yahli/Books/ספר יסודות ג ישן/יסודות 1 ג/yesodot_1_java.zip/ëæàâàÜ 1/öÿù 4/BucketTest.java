import unit4.bucketLib.*;
public class BucketTest 
{
  	public static void main(String[] args) 
  	{
    		Bucket b = new Bucket(100,"BUCK");
    		b.fill(50);
  	} // main
} // classs BucketTest 
