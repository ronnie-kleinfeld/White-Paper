/*
������� ���� ������ ������� +, -, * �-/    
*/
import java.util.Scanner;
public class Calculator 
{
public static void main(String[] args) 
{
// ����� �� ������ �������
Scanner in = new Scanner(System.in);
double num1; // first operand
double num2; // second operand
char operator;	
double result;	
// ����� �������
	System.out.print("Enter the first number: ");
	num1 = in.nextDouble();
	System.out.print("Enter the operator: ");
	operator = in.next().charAt(0);
	System.out.print("Enter the second number: ");	        
	num2 = in.nextDouble();
	switch (operator)
{
	case '+': 
	result = num1 + num2
	System.out.println(num1 + "+" + num2 + "=" + result);
break;
	case '-':
	result = num1 - num2;
	System.out.println(num1 + "-" + num2 + "=" + result);
break;
	case '*':
	result = num1 * num2;
	System.out.println(num1 + "*" + num2 + "=" + result);
break;
	case '/':
	if (num2 != 0)
{
	  	result = num1 / num2;
        	System.out.println(num1 + "/" + num2 + "=" +
result);
}
	else
        	System.out.println("Division by 0");
break;
	default: System.out.println("Illegal operator");
} // switch
} // main
} // class Calculator
