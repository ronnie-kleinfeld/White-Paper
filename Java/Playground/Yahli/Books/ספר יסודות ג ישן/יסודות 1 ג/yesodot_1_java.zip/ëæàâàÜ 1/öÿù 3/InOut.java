import java.util.Scanner;
public class InOut
{ 
	public static void main (String [] args) 
{
       Scanner in = new Scanner(System.in);
int num1;
int num2;
System.out.print("Enter first number: ");
      num1 = in.nextInt();
System.out.print("Enter second number: ");
      num2 = in.nextInt();
System.out.println(num1);
System.out.println(num2);
System.out.print("Enter another one: ");
num2 = in.nextInt(); 
System.out.println(num1);
System.out.println(num2);
}
}		
