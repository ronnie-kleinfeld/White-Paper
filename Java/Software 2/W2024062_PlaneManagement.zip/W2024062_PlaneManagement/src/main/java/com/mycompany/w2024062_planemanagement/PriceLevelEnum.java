package com.mycompany.w2024062_planemanagement;

public enum PriceLevelEnum {
    firstClass,
    business,
    tourist
}