package com.mycompany.w2024062_planemanagement;

public enum ExistsEnum {
    exists,
    notExists
}