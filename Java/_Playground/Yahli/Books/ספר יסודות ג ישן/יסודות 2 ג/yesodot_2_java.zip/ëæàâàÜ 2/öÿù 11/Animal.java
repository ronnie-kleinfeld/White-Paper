public class Animal 	
{	   
	private String kind = "";	// ���

	public void setKind (String Kind)
	{
		this.kind = Kind;
	}
	public String getKind ()
	{
		return kind;
	}
} // class Animal
