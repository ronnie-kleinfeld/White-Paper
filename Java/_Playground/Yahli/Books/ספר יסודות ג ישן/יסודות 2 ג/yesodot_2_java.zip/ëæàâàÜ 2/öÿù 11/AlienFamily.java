/*
����� ����� ������ ���� ����� �� ������
*/
import java.util.Scanner;
public class AlienFamily 
{
	public static void main(String[] args)
	{
		String firstName;
		String lastName;
		String planet;
		String favoriteFood;
		boolean foundRelative = false;
		Alien bonbon = new Alien("Bonbon","Alf","Melmack","pizza");
		Alien relative;
		int counter = 0;
		Scanner in = new Scanner(System.in);
		while (!foundRelative && counter < 50)
		{
			System.out.println("---Looking for a relative--- ");
			counter ++;
			System.out.print("Enter first name: ");
			firstName = in.nextLine();
			System.out.print("Enter last name: ");
			lastName = in.nextLine();
			System.out.print("Where do you come from? ");
			planet = in.nextLine();
			System.out.print("What is your favorite food? ");
			favoriteFood = in.nextLine();
			relative = new Alien(firstName,lastName,planet,favoriteFood);
			foundRelative = bonbon.isRelative(relative);
		}
		if (foundRelative)
			System.out.println("A relative was found. " + 
					   "Thank you for your participation");
		else
			System.out.println("The search ended with no luck");     
	}// main
}// AlienFamily
