/*
���: ��� ������ �������
���: _________________________________
*/
import java.util.Scanner;
public class Letters
{
public static void main (String[] args)
{
char[] letters = new char[10];
for (int i = 0; i < letters.length; i++)
{
System.out.print("Enter a character: ");
letters[i] = in.nextLine().charAt(0);
} // for
for (int i = 0; i < letters.length; i++)
if (letters[i] == letters[letters.length -1] )
System.out.println(i);
} // main
} // Letters