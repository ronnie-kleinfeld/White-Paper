/*
������ Teacher
*/
public class Teacher
{
	final int NUM_OF_STUDENTS = 40;
	private Student[] students;
	private int numOfStudents;
	//����� ���� 
	public Teacher()
	{
		students= new Student [NUM_OF_STUDENTS];
		numOfStudents=0;
	}
	public Student[] getStudents()
	{
		Student[] studs = new Student[numOfStudents];
		for(int i = 0; i < numOfStudents; i++)
			studs[i] = new Student(students[i].getName(),
				students[i].getHistoryGrade()); 
		return studs;
	}
	public Student getStudentByName(String name)
	{
		for(int i = 0; i < numOfStudents; i++)
			if (students[i].getName().equals(name))
				return new Student(students[i].getName(),
					students[i].getHistoryGrade()); 
		return null; // �� ���� ����� ��� ��
	}
	public void insertStudent(Student stud)
	{
		int i = numOfStudents - 1;
		while (i >= 0 && 
			students[i].getHistoryGrade() > stud.getHistoryGrade()) 
		{
			students[i+1] = students[i];
			i--;
		}//while
		students[i+1] = new Student(stud.getName(),
			stud.getHistoryGrade()); 
		numOfStudents++;
	}
}
