/* ����� ����� */
public class Alien
{
	private String firstName;
	private String lastName;
	private String planet;
	private String favoriteFood;
	public Alien (String firstName, String lastName, String planet,
		String favoriteFood)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.planet = planet;
		this.favoriteFood = favoriteFood;
	}
	public boolean isRelative (Alien relative)
	{
		if (lastName.equals(relative.lastName) &&
			planet.equals(relative.planet) &&
			favoriteFood.equals(relative.favoriteFood))
			return true;
		else
			return false;
	}
}// Alien
