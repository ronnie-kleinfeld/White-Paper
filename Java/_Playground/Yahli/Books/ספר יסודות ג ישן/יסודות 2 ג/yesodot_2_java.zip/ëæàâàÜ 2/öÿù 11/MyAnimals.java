public class MyAnimals
{
	public static void main(String[] args)
	{
		Animal ani = new Animal();
		Animal [] myAnimals = new Animal[3];
		ani.setKind("dog");
		myAnimals[0] = ani;
		ani.setKind("cat");
		myAnimals[1] = ani;
		ani.setKind("fish");
		myAnimals[2] = ani;
		System.out.println("My animals are "+myAnimals[0].getKind()+ 
				   " " + myAnimals[1].getKind()+ " " + myAnimals[2].getKind());
	} // main
} // class MyAnimals
