/*
������ ������ ������ �� ���� ��������
*/
import java.util.Scanner;
public class GuessGame 
{
	public static void main(String[] args)
	{
		String prize = "1 million dollars";
		GuessForm guessForm = new GuessForm(prize);
		int guess;
		int i = 0;
		Scanner in = new Scanner(System.in);
		while ((i < 10) && (guessForm.isWin() == false))
		{
			i++;
			System.out.print("Please enter your guess: ");
			guess = in.nextInt();
			if (guessForm.isGoodGuess(guess))
				System.out.println("Good Guess");      
			else
				System.out.println("Bad Guess");
		}
		if (guessForm.isWin())
			System.out.println("You win: " + guessForm.getPrize());
		else
			System.out.println("You lose: "+ guessForm.getPrize()); 
	}// main
}// GuessGame
