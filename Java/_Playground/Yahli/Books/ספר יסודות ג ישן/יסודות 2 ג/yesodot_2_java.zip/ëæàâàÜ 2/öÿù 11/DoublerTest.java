public class DoublerTest
{
	public static void main(String[] args)
	{
		int num = 2;
		System.out.println("num is " + num);
		Doubler.doubleIt(num);
		System.out.println("num after double is " + num);
	} // main
} //DoublerTest
