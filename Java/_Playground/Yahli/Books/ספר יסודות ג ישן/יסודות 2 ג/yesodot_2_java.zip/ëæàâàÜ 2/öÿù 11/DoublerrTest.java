public class DoublerrTest
{
	public static void main(String[] args)
	{
		Doublerr doubler1 = new Doublerr(5);
		Doublerr doubler2 = new Doublerr(4);
		System.out.println("doubler1 is " + doubler1.getNum());
		doubler1.doubleNum();
		System.out.println("doubler1 after doubleNum is "+ 
				   doubler1.getNum());
		System.out.println("doubler2 is " + doubler2.getNum());
		doubler1.doubleIt(doubler2);
		System.out.println("doubler2 after doubleIt is" +
				   doubler2.getNum());
	} // Main
} //DoublerrTest
