/*
����� ����� ������� ������ �������
*/
import java.util.Scanner;
public class CalculatorTest 
{
	public static void main(String[] args)
	{
		int operation;
		int num;
		int num1;
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter the number of the "+
				   "operation you would like to perform:");
		System.out.println("1: power");
		System.out.println("2: is power");
		System.out.println("3: digit sum");
		operation = in.nextInt();
		switch (operation)
		{
			case 1:
				System.out.print("Please enter the base number: ");
				num = in.nextInt();
				System.out.print("Please enter the exponent: ");
				num1 = in.nextInt();
				System.out.println(num + " ^ " + num1 + " = " +
						   Calculator.power(num,num1));
				break;
			case 2:
				System.out.print("Please enter the result: ");
				num = in.nextInt();
				System.out.print("Please enter the base: ");
				num1 = in.nextInt();
				if (Calculator.isPower(num,num1))
					System.out.println(num + " is a power of " 
							   + num1);
				else
					System.out.println(num + " is not a power of "
							   + num1);
				break;
			case 3:
				System.out.print("Please enter a number: ");
				num = in.nextInt();
				System.out.println("The digit sum of " + num + 
						   " is " + Calculator.digitSum(num));
				break;
			default:
				System.out.println("Wrong option");
		}// Switch
	}// main
}// ClaculatorTest
