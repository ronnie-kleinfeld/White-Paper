public class Doubler
{
	public static void doubleIt(int num)
	{
		num = num * 2;
		System.out.println("Doubled: num = " + num);
	} 
}// Doubler
