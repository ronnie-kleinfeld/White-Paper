public class Doublerr
{
	private double num;
	public Doublerr(double num)
	{
		this.num = num;
	}
	public double getNum()
	{
		return num;
	}
	public void doubleNum()
	{
		num = num * 2;
		System.out.println("Doubled = " + num);
	}
	public void doubleIt(Doublerr it) 
	{
		it.doubleNum();
		System.out.println("Doubled: it = "+it.getNum());
	}
}// Doublerr
